

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyDHj2Yu7b9BXWKKcZ8UFEcs9nUS3LLEyiU",
  authDomain: "story-telling-app-f372c.firebaseapp.com",
  projectId: "story-telling-app-f372c",
  storageBucket: "story-telling-app-f372c.appspot.com",
  messagingSenderId: "1087090609026",
  appId: "1:1087090609026:web:de35d8ab6215fffaa71d9b"
};

// Initialize Firebase
//const app = initializeApp(firebaseConfig);